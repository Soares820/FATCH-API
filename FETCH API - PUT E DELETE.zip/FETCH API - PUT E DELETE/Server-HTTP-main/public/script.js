async function carregarAulas() {
    try {
        console.log("GET para endpoint /aulas");

        const response = await fetch("http://localhost:3000/aulas");
        const aulas = await response.json();

        console.log("Resposta da API:", aulas);

        const container = document.getElementById("aulas-container");
        container.innerHTML = ""; 

       
        aulas.forEach((aula) => {
            const card = document.createElement("div");
            card.classList.add("aula-card");

            card.innerHTML = `
                <span><strong>ID:</strong> ${aula.id}</span>
                <h2>${aula.title}</h2>
                <p>${aula.content}</p>
                <button onclick="editarAula(${aula.id}, '${aula.title}', '${aula.content}')">Editar</button>
                <button onclick="excluirAula(${aula.id})">Excluir</button>
            `;

            container.appendChild(card);
        });

    } catch (error) {
        console.error("Erro ao carregar as aulas:", error);
    }
}

async function adicionarAula() {
    const title = document.getElementById("title").value;
    const content = document.getElementById("content").value;

    const dados = { title: title, content: content };
    console.log(dados);

    try {
        console.log("POST para endpoint /aulas");
        const response = await fetch("http://localhost:3000/aulas", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(dados)
        });

        if (response.ok) {
            console.log("Aula adicionada com sucesso!");
            carregarAulas();
        } else {
            console.error("Erro ao adicionar aula:", response.statusText);
        }
    } catch (error) {
        console.error("Erro ao adicionar aula:", error);
    }
}

async function excluirAula(id) {
    try {
        console.log(`DELETE para /aulas/${id}`);
        const response = await fetch(`http://localhost:3000/aulas/${id}`, {
            method: "DELETE"
        });

        if (response.ok) {
            alert("Aula excluída com sucesso!");
            carregarAulas();
        } else {
            console.error("Erro ao excluir aula:", response.statusText);
        }
    } catch (error) {
        console.error("Erro ao excluir aula:", error);
    }
}

async function editarAula(id, oldTitle, oldContent) {
    const novoTitulo = prompt("Novo título da aula:", oldTitle);
    const novoConteudo = prompt("Novo conteúdo da aula:", oldContent);

    if (!novoTitulo || !novoConteudo) {
        alert("Edição cancelada.");
        return;
    }

    const dadosAtualizados = { title: novoTitulo, content: novoConteudo };

    try {
        console.log(`PUT para /aulas/${id}`);
        const response = await fetch(`http://localhost:3000/aulas/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(dadosAtualizados)
        });

        if (response.ok) {
            alert("Aula atualizada com sucesso!");
            carregarAulas();
        } else {
            console.error("Erro ao editar aula:", response.statusText);
        }
    } catch (error) {
        console.error("Erro ao editar aula:", error);
    }
}
